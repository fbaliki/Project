import { describe, it, expect, beforeEach } from 'vitest';
import { gameLoop, fishCollisionChecker} from 'OverFilled.js';


//test to see if fish is dropping when player presses e
describe('Fish spawning tests', () => {
  let gameScreen, dropper;

  beforeEach(() => {
    // Mocking the DOM elements here instead of testing this in a browser
    gameScreen = document.createElement('div');
    gameScreen.setAttribute('id', 'gameScreen');
    document.body.appendChild(gameScreen);

    dropper = document.createElement('div');
    dropper.setAttribute('id', 'dropper');
    gameScreen.appendChild(dropper);
  });

  it('spawns a fish when "E" key is pressed', () => {
    const event = new KeyboardEvent('keydown', { key: 'e' });
    document.dispatchEvent(event);

    const fish = gameScreen.querySelector('div:not(#dropper)');
    expect(fish).not.toBeNull();
    expect(fish.style.position).toBe('absolute');
  });
});



//test to see if dropper is moving properly
describe('Dropper movement tests', () => {
    let dropper;
  
    beforeEach(() => {
      dropper = document.createElement('div');
      dropper.setAttribute('id', 'dropper');
      dropper.style.left = '200px';
      document.body.appendChild(dropper);
    });


//left movement tests:
    it('moves left when "ArrowLeft" is pressed', () => {
      const event = new KeyboardEvent('keydown', { key: 'ArrowLeft' });
      document.dispatchEvent(event);
  
      const newPosition = parseInt(dropper.style.left);
      expect(newPosition).toBeLessThan(200);
    });

    it('moves left when key "a" is pressed', () => {
        const event = new KeyboardEvent('keydown', { key: 'a' });
        document.dispatchEvent(event);
    
        const newPosition = parseInt(dropper.style.left);
        expect(newPosition).toBeLessThan(200);
      });

//incase player has caps lock on
      it('moves left when key "A" is pressed', () => {
        const event = new KeyboardEvent('keydown', { key: 'A' });
        document.dispatchEvent(event);
    
        const newPosition = parseInt(dropper.style.left);
        expect(newPosition).toBeLessThan(200);
      });


//right movement tests:
    it('moves right when "ArrowRight" is pressed', () => {
      const event = new KeyboardEvent('keydown', { key: 'ArrowRight' });
      document.dispatchEvent(event);
  
      const newPosition = parseInt(dropper.style.left);
      expect(newPosition).toBeGreaterThan(200);
    });

    it('moves right when key "d" is pressed', () => {
        const event = new KeyboardEvent('keydown', { key: 'd' });
        document.dispatchEvent(event);
    
        const newPosition = parseInt(dropper.style.left);
        expect(newPosition).toBeGreaterThan(200);
      });
  
//incase of caps lock on
    it('moves right when key "D" is pressed', () => {
        const event = new KeyboardEvent('keydown', { key: 'D' });
        document.dispatchEvent(event);
    
        const newPosition = parseInt(dropper.style.left);
        expect(newPosition).toBeGreaterThan(200);
      });



//tests so that the dropper doesn't leave the area
    it('does not move left past 0', () => {
      dropper.style.left = '0px';
      const event = new KeyboardEvent('keydown', { key: 'ArrowLeft' });
      document.dispatchEvent(event);
  
      const newPosition = parseInt(dropper.style.left);
      expect(newPosition).toBe(0);
    });
  
    it('does not move right past 380px', () => {
      dropper.style.left = '380px';
      const event = new KeyboardEvent('keydown', { key: 'ArrowRight' });
      document.dispatchEvent(event);
  
      const newPosition = parseInt(dropper.style.left);
      expect(newPosition).toBe(380);
    });
  });


  //fish merging test:
  describe('Fish collision tests', () => {
    it('detects collision between two fish', () => {
      const fish1 = document.createElement('div');
      const fish2 = document.createElement('div');
  
      fish1.getBoundingClientRect = vi.fn(() => ({ x: 10, y: 10, width: 50, height: 50 }));
      fish2.getBoundingClientRect = vi.fn(() => ({ x: 30, y: 30, width: 50, height: 50 }));
  
      fishArray.push(fish1, fish2);
  
      const collision = fishCollisionChecker(fish1);
      expect(collision).toBe(true); // Expect fish to merge
    });
  
    it('does not detect collision if fish are far apart', () => {
      const fish1 = document.createElement('div');
      const fish2 = document.createElement('div');
  
      fish1.getBoundingClientRect = vi.fn(() => ({ x: 10, y: 10, width: 50, height: 50 }));
      fish2.getBoundingClientRect = vi.fn(() => ({ x: 100, y: 100, width: 50, height: 50 }));
  
      fishArray.push(fish1, fish2);
  
      const collision = fishCollisionChecker(fish1);
      expect(collision).toBe(false); // fish didn't merge
    });
  });


//test for high score update
describe('High score tests', () => {
    let bestHighScore;
  
    beforeEach(() => {
      bestHighScore = 0;
      localStorage.setItem('bestHighScore', bestHighScore);
    });
  
    it('updates high score if current score is higher', () => {
      hightscore = 100;
      gameLoop();
  
      expect(localStorage.getItem('bestHighScore')).toBe('100');
    });
  
    it('does not update high score if current score is lower', () => {
      localStorage.setItem('bestHighScore', '200');
      hightscore = 150;
      gameLoop();
  
      expect(localStorage.getItem('bestHighScore')).toBe('200');
    });
});



//test for sound and volume buttons
describe('Sound button tests', () => {
    let soundButton, musicVolumeDiv, soundVolumeDiv;
  
    beforeEach(() => {
      soundButton = document.createElement('button');
      soundButton.setAttribute('id', 'soundButton');
  
      musicVolumeDiv = document.createElement('div');
      musicVolumeDiv.setAttribute('id', 'musicVolume');
      musicVolumeDiv.style.display = 'none';
  
      soundVolumeDiv = document.createElement('div');
      soundVolumeDiv.setAttribute('id', 'soundVolume');
      soundVolumeDiv.style.display = 'none';
  
      document.body.appendChild(soundButton);
      document.body.appendChild(musicVolumeDiv);
      document.body.appendChild(soundVolumeDiv);
    });
  
    it('toggles visibility of volume sliders', () => {
      soundButton.click();
      expect(musicVolumeDiv.style.display).toBe('block');
      expect(soundVolumeDiv.style.display).toBe('block');
  
      soundButton.click();
      expect(musicVolumeDiv.style.display).toBe('none');
      expect(soundVolumeDiv.style.display).toBe('none');
    });
  });




  