//F: added testing environment so that vitest would recognize DOM objects like "document"
//installed happy dom


import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    environment: 'happy-dom', 
  },
});