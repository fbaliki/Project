// variables obtain the game screen and dropper
const gameScreen = document.getElementById("gameScreen");
const dropper = document.getElementById("dropper");
const restartButton = document.getElementById("restart"); // Get the button
var highscoreVisual = document.getElementById("highscore");
const gameOver = document.getElementById("gameOverScreen");
const bestScore = document.getElementById("bestScore");
var hightscore = 0; // highscore value
let bestHighScore = localStorage.getItem("bestHighScore"); // used for saving the users data
let currentFishType = 0; // states the current fish type that is being recorded
let delayForInput = false; //  sets a delay for the input
let interval; // used as an interval for different action involving looping functions
let fishArray = []; // stores all the fish elements
let both = 0; // To check if both of the inputs are being pressed
let playMode = true; // used for pausing the game
// function for the restart button

restartButton.addEventListener('click', function() {
  localStorage.setItem
    location.reload(); // Restarts the page
});
// detects the input and outputs the droppers movement
function moveLeft() {
  let positionOfDropper = parseInt(window.getComputedStyle(dropper).getPropertyValue("left"));
  if (positionOfDropper > 0) {
    dropper.style.left = positionOfDropper - 2 + "px";
  }
}

function moveRight() {
  let positionOfDropper = parseInt(window.getComputedStyle(dropper).getPropertyValue("left"));
  if (positionOfDropper < 380) {
    dropper.style.left = positionOfDropper + 2 + "px";
  }
}

// obtains the offset of any element
function getOffset(obj) {
  const objPos = obj.getBoundingClientRect();
  const gameScreenPos = gameScreen.getBoundingClientRect();
  return {
    left: objPos.left - gameScreenPos.left + window.scrollX,
    top: objPos.top - gameScreenPos.top + window.scrollY
  };
}

// Event listener detects the input from the player
document.addEventListener("keydown", event => {
  if (both == 0) {
    both++;
    if (event.key === "ArrowLeft" || event.key === "a") {
      interval = setInterval(moveLeft, 1);
    }
    if (event.key === "ArrowRight" || event.key === "d") {
      interval = setInterval(moveRight, 1);
    }
  }

  if (event.key === "e" && delayForInput == false) {
    // when e is pressed, a random fish will spawn
    delayForInput = true;
    
    
    let fish = document.createElement("div");
    let fishDropPool = Math.floor(Math.random() * 4); // will rotate between a few fish types
    FishType(fishDropPool, fish);
    FishSpawnPosition(fish, 40); // Positions below the dropper
    setTimeout(() => {
      delayForInput = false;
    }, 1000); // used to create a delay between each input
  }
});

// Event listener for keyup to stop movement of the dropper
document.addEventListener("keyup", event => {
  clearInterval(interval);
  both = 0;
  
});

// function sets the spawn position of the fish
function FishSpawnPosition(fish, depthFromDropper) {
  let offsetOfDropper = getOffset(dropper);
  fish.style.position = "absolute";
  fish.style.left = offsetOfDropper.left + "px";
  fish.style.top = (offsetOfDropper.top + depthFromDropper) + "px"; 
  gameScreen.append(fish);
}

// function sets the spawn position of the fish after they merge
function fishNewPosition(fish, fishNewPositionInSpace) {
  fish.style.position = "absolute";
  fish.style.left = fishNewPositionInSpace.left + "px";
  fish.style.top = fishNewPositionInSpace.top + "px"; 
  gameScreen.append(fish);
}

// Gravity function drops the fish when they aren't colliding
function fishGravity(fish) {
  fish.gravity = 0.1;
  fish.speedY = 0;
  
  function update() {
    fish.speedY += fish.gravity;
    let newPosition = parseFloat(fish.style.top) + fish.speedY;
    if(newPosition - fish.offsetHeight < 20 )
    {
      console.log("game over");
      
      gameOver.style.display = "block";
      
    }
    // if statement makes sure the fish cannot fall off the screen
    if (newPosition < 500 - fish.offsetHeight && !fishCollisionChecker(fish)) {
      fish.style.top = newPosition + "px";
      requestAnimationFrame(update);

    } else if (fishCollisionChecker(fish)) {
      fish.style.top = fish.style.top; // Stop if colliding
    }
      
     else {
      fish.style.top = (500 - fish.offsetHeight) + "px"; // Stop at the bottom
      fish.speedY = 0;
    }
  }
  requestAnimationFrame(update);
}

// fish collision checker is used as a detector for the collision
function fishCollisionChecker(fish) {
  for (let i = 0; i < fishArray.length; i++) {
    const otherFish = fishArray[i];
    if (otherFish === fish || !otherFish) continue; // Skip itself and undefined fish

    const colliderA = fish.getBoundingClientRect();
    const colliderB = otherFish.getBoundingClientRect();

    // Check if the two fish are colliding
    if (colliderA.x < colliderB.x + colliderB.width &&
        colliderA.x + colliderA.width > colliderB.x &&
        colliderA.y < colliderB.y + colliderB.height &&
        colliderA.y + colliderA.height > colliderB.y) {
      return true; 
    }
  }
  return false; 
}

// Function to perform an action when the collision occurs
function fishCollision() {
  let fishToRemove = [];  // Track fish to be removed after the loop
  const mergeSound = document.getElementById("mergeSound"); //MOOSE

  for (let i = 0; i < fishArray.length; i++) {
    for (let j = i + 1; j < fishArray.length; j++) {
      const fishA = fishArray[i];
      const fishB = fishArray[j];

      if (!fishA || !fishB) continue;  // Skip undefined fish

      const colliderA = fishA.getBoundingClientRect();
      const colliderB = fishB.getBoundingClientRect();

      // checks if two parts are colliding
      if (colliderA.x < colliderB.x + colliderB.width &&
          colliderA.x + colliderA.width > colliderB.x &&
          colliderA.y < colliderB.y + colliderB.height &&
          colliderA.y + colliderA.height > colliderB.y) {

        if (JSON.stringify([...fishA.classList].sort()) === JSON.stringify([...fishB.classList].sort())) {
          // Play the merge sound
          mergeSound.currentTime = 0; //MOOSE
          mergeSound.play();

          // Merge logic
          let fishPosition = getOffset(fishA);
          let fishIdNumber = parseInt(fishA.id.replace(/\D/g, ""));

          // Mark the fish for removal
          fishToRemove.push(fishA, fishB);

          // Remove the merged fish and create a new one
          let fish = document.createElement("div");
          FishType(fishIdNumber + 1, fish);
          fishNewPosition(fish, fishPosition);

          // Apply gravity to the new fish
          fishGravity(fish);
        } else {
          // if they are colliding it will push the block upwards
          let fishBTop = parseInt(fishB.style.top) || 0;
          fishB.style.top = (fishBTop - 1) + "px";
        }
      }
    }
  }

  // Remove marked fish after the loop finishes
  fishToRemove.forEach(fish => {
    const index = fishArray.indexOf(fish);
    if (index !== -1) {
      fishArray.splice(index, 1); // Remove from array
      fish.remove(); // Remove from DOM
    }
  });
}

// function creates the fish based on its id
function FishType(IdOfFish, fish) {
  switch (IdOfFish) {
    case 0:
      fish.setAttribute("class", "fishZero");// class defines the class that the program will inherit its css properties from
      fish.setAttribute("id", "0"); // id sets the numeric value that the fish compare when colliding to detect if they should merge
      hightscore += 10; // increments the highscore when the object is spawned
      break;
    case 1:
      fish.setAttribute("class", "fishOne");
      fish.setAttribute("id", "1");
      hightscore += 20;
      break;
    case 2:
      fish.setAttribute("class", "fishTwo");
      fish.setAttribute("id", "2");
      hightscore += 30;
      break;
      case 3:
      fish.setAttribute("class", "fishThree");
      fish.setAttribute("id", "3");
      hightscore += 40;
      break;
    case 4:
      fish.setAttribute("class", "fishFour");
      fish.setAttribute("id", "4");
      hightscore += 50;
      break;
      case 5:
      fish.setAttribute("class", "fishFive");
      fish.setAttribute("id", "5");
      hightscore += 60;
      break;
    case 6:
      fish.setAttribute("class", "fishSix");
      fish.setAttribute("id", "6");
      hightscore += 70;
      break;
    case 7:
      fish.setAttribute("class", "fishSeven");
      fish.setAttribute("id", "7");
      hightscore += 80;
      break;
      case 8:
      fish.setAttribute("class", "fishEight");
      fish.setAttribute("id", "8");
      hightscore += 100;
      break;
    case 9:
      fish.setAttribute("class", "fishNine");
      fish.setAttribute("id", "9");
      hightscore += 150;
      break;
    case 10:
      fish.setAttribute("class", "fishTen");
      fish.setAttribute("id", "10");
      hightscore += 200;
      break;
    default:
      fish.setAttribute("class", "fishZero");
      fish.setAttribute("id", "0");
      hightscore += 10;
      break;
  }

  fishGravity(fish); // applies the gravity to the fish
  fishArray.push(fish); // this will put the fish into the array
}

// saves a best score to the localscript
if (bestHighScore === null) {
  bestHighScore = 0; // sets the best score to 0 if there alreadu is no score
} else {
  bestHighScore = parseInt(bestHighScore);// sets the best score to the local save score currently being handled
}

// Function to handle the game loop
function gameLoop() {
  // Update best score if current score is greater than bestHighScore
  if (hightscore > bestHighScore) {
    bestHighScore = hightscore;// sets the highscore to the best score if they player surpases their score
    localStorage.setItem("bestHighScore", bestHighScore);  // Save to localStorage
  }

  // Display the best score with visual text
  bestScore.innerHTML = "Best Score: " + bestHighScore;

  // Continue other game loop functions
  fishCollision(); // Check for fish collisions
  window.requestAnimationFrame(gameLoop); // Repeat the game loop

  // Update visual highscore display
  highscoreVisual.innerHTML = hightscore;
  console.log(hightscore);
}

// Start the game loop
window.requestAnimationFrame(gameLoop);


//MOOSE
const soundButton = document.getElementById("soundButton");
const musicSlider = document.getElementById("musicSlider");
const soundSlider = document.getElementById("soundSlider");
const musicAudio = document.getElementById("gameAudio"); // Music audio element
const soundEffectsAudio = document.getElementById("soundEffectsAudio"); // Sound effects audio element
// Function to handle the game loop
let isMusicPlaying = false;

document.addEventListener("DOMContentLoaded", function () {
  const musicAudio = document.getElementById("gameAudio");
  const soundEffectAudio = document.getElementById("soundEffect");
  
  const musicSlider = document.getElementById("musicSlider");
  const soundSlider = document.getElementById("soundSlider");

  const musicVolumeDiv = document.getElementById("musicVolume");
  const soundVolumeDiv = document.getElementById("soundVolume");

  // Initially hide the volume sliders
  musicVolumeDiv.style.display = "none";
  soundVolumeDiv.style.display = "none";

  // Toggle sound volume visibility
  const soundButton = document.getElementById("soundButton");
  soundButton.addEventListener("click", function () {
    if (musicVolumeDiv.style.display === "none") {
      musicVolumeDiv.style.display = "block";
      soundVolumeDiv.style.display = "block";
    } else {
      musicVolumeDiv.style.display = "none";
      soundVolumeDiv.style.display = "none";
    }
  });

  // Play music when the "E" key is pressed (if not already playing)
  document.addEventListener("keydown", function (event) {
    if (event.key === "e") {
      if (!isMusicPlaying) {
        musicAudio.loop = true;
        musicAudio.play().catch((error) => {
          console.error("Error playing the background music:", error);
        });
        isMusicPlaying = true;
      }
      playSoundEffect();  // Play sound effect when "E" is pressed
    }
  });

  // Adjust music and sound effect volumes
  musicSlider.addEventListener("input", function () {
    musicAudio.volume = musicSlider.value / 100;
  });
  soundSlider.addEventListener("input", function () {
    soundEffectAudio.volume = soundSlider.value / 100;
  });

  // Play sound effect manually
  function playSoundEffect() {
    soundEffectAudio.currentTime = 0;
    soundEffectAudio.play();
  }
});
